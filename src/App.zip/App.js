import React, { useState, useMemo } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { AppContext } from "./Components/AppContext";
import Header from "./Components/Header";
import Home from "./Pages/Home";
import AboutPage from "./Pages/AboutPage";
import Main from "./Pages/Main";

function App() {
  const [loginUser, setLoginUser] = useState(null);

  const loginUserValue = useMemo(() => ({ loginUser, setLoginUser }), [
    loginUser,
    setLoginUser,
  ]);

  return (
    <div>
      <div
        className="bg-scroll bg-no-repeat bg-cover bg-center w-screen h-screen"
        style={{
          backgroundImage: "url('bgimg.jpg')",
        }}
      >
        <Router>
          <AppContext.Provider value={loginUserValue}>
            <Header />
            <Main />
          </AppContext.Provider>

          <div>
            <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/about" component={AboutPage} />
            </Switch>
          </div>
        </Router>
      </div>
    </div>
  );
}

export default App;
